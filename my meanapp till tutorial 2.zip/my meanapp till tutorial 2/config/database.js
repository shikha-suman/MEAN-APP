module.exports = {
    database: 'webtechdevops.centralindia.cloudapp.azure.com:51003/shikhaDB'

}